<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wyszukaj uzytkownika</title>
</head>
<body>
    <h2>Wyszukaj uzytkownika</h2>
    <form action="forSearch.php" method="post">
        <label for="email">Podaj email: </label>
        <input type="email" name="email" id="email" required>
        <br><br>
        <button type="submit">Szukaj</button>
    </form>
</body>
</html>