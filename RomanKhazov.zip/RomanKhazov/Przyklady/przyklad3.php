<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>  
<?php

    $x = 11;
    $y = 7;
    $z = $x + $y;
    
    if ($z < 0)     
        echo "Waryosc zmiennej z  jest ujemna ";
    elseif($z <= 10)
        echo "Waryosc zmiennej z jest w zakresie od 0 do 10 ";
    elseif($z <= 20)
        echo "Waryosc zmiennej z jest w zakresie od 10 do 20 ";
    elseif($z <= 30)
        echo "Waryosc zmiennej z jest w zakresie od 20 do 30 ";
    else
        echo"Wartosc zmiennej z jest wieksza niz 30 " ;
?>
</body>
</html>