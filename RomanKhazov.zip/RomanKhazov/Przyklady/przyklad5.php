<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        $x = 11; 
        $wynik = ($x < 0) ? "ujemna":"dodatnia";
        echo "wartosc zmiennj x jest $wynik"
?>
</body>
</html>