<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $wynik = 77;

    if($wynik < 60)
    echo"Twoja ocena = F";
    elseif($wynik < 70)
    echo"Twoja ocena = D";
    elseif($wynik < 80)
    echo"Twoja ocena = C";
    elseif($wynik < 90)
    echo"Twoja ocena = B";
    else
    echo"Twoja ocena = A";
?>
</body>
</html>