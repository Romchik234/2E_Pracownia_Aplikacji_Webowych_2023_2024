<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        $produkt = "Books";
        $cenaBook = 30;
        echo"Produkt = $produkt  Bez znizki cena = $cenaBook  <br>";

        switch ($produkt) {
            case 'Electronics':
                echo"znizka 10%";
                break;
            
            case "Clothing":
                echo"znizka 20%";
                break;

            case 'Books': 
                echo"Znizka 5%  Nowa cena =". $cenaBook * 0.95;
                break; 
            default:
                echo"Karamba nie ma tego produkta";
        }

?>
</body>
</html>