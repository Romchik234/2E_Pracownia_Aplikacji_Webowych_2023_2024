<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php

    $x = 322;

    if($x < 50)
    echo"Dobra jakosc powietrza";
    elseif($x < 100)
    echo"Umiarkowana jakosc powietrza";
    elseif($x < 150)
    echo"Zla jakosc powietrza";
    elseif($x < 200)
    echo"bardzo zla jakosc powietrza";
    elseif($x < 300)
    echo"Szkodliwa jakosc powietrza";
    else
    echo"Niebezpieczna jakosc powietrza";

?> 

</body>
</html>