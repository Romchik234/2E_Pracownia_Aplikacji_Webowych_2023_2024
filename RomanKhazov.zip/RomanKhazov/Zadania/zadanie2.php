<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>  
<?php
    $dzien = "sobota";

    switch ($dzien) {
        case 'poniedzialek':
            echo"Poniedzialek - jabko";
            break;
        
        case 'wtorek':
            echo"wtorek - gruszka";
            break;

        case 'sroda':
            echo"sroda - lemon";
            break;

        case 'czwartek':
            echo"Czwartek - winogrono";
            break;

        case 'piatek':
            echo"piatek - kiwi";
            break;

        case 'sobota':
            echo"sobota - pomarancza";
            break;

        case 'niedziela':
            echo"niedziela - awokada";
            break;

        default:
            echo"zly dzien tygodnia";
    }




?>
</body>
</html>