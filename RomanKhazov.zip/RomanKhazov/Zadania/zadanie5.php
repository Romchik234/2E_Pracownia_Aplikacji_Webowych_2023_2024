<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $kg = 14;

        if($kg <= 1)
            echo"list zwykly";
        elseif($kg <= 5)
            echo"mala paczka";
        elseif($kg <= 10)
            echo"srednia paczka";
        elseif($kg <= 20)
            echo"Duza paczka";
        else
            echo"Przesulka kurierska";

    ?>
</body>
</html>