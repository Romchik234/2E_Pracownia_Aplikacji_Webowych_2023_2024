function calculate()
{
    var sum = (document.querySelector("#adult").value * 120) + (document.querySelector("#kids").value * 70) + (document.querySelector("#family").value * 200) + (document.querySelector("#foradam").value * 1200); 
    document.getElementById("sum").innerText = "Sum: " ;
    document.getElementById("sum").innerText +=  sum + "$" ;
    document.getElementById("double").innerText = "Double click to confirm";
}

function confirm()
{
    window.location.replace('paymentPage.php');

}