<?php

$host = "localhost";
$user = "root"; // domyślny użtytkownik sql 
$pass = "";   // haslo puste 
$dbname = "UsersData"; 

$conn = new mysqli($host,$user,$pass,$dbname); 

if ($conn -> connect_error)
     {
         die("Błąd połacznie: " . $conn->connect_error); 
     }

     if($_SERVER["REQUEST_METHOD"]=="POST")
     {
         $email = $_POST["email"];
         $password = $_POST["password"];
     }


//skrypt LoginPage.php

session_start(); 

if(isset($_SESSION['log'])){

    header('location: shopPage.php');
    exit();

}elseif(isset($_POST["email"]) && isset($_POST['password'])) { 

    $sql = "SELECT * FROM `user` WHERE login = '$email';"; //register and check if email already exist next send to login page and text that u 
    $result = $conn -> query($sql);                         //seccesfuly registred (or send to another page where u say that you registred and button go to login )

    if($result -> num_rows > 0 )
    {
        echo"<script>alert('This login is already taken')</script>"; 
    }else{ 
            $sql = "INSERT INTO `user`(`id`, `login`, `password`) VALUES ('[value-1]','$email','$password')";
            $conn -> query($sql);   
            $_SESSION['log']= $email; 
            echo"<script>alert('Successfully registred ! Now you can Login')</script>";   
           header("refresh: 1,url=loginPage.php");
        }
    }
  $conn -> close(); 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ZooLogin</title>
    <link rel="stylesheet" href="logStyle.css">
</head>
<body>
<a href="Zoo-website.php"><button id="back">Back to Site</button></a>
    <div id="formPage">
    
        <h1> Sign On </h1>
        <form action="https://localhost/zoo-Website/signinPage.php" method="POST">
            <p >Email: </p>
            <input class="logPut" type="email" name="email" value=""  size="25" required><br/>
            <p >Password: </p>
            <input class="logPut" type="password" name="password" value="" size="25" required><br/>
            <input id="submit" type="submit" value="Submit">
        </form>
      
       or  <a href="loginPage.php"><button id="signin">Log In</button></a>

    </div>
    
</body>
</html>