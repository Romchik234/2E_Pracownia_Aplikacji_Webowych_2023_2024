<?php

$host = "localhost";
$user = "root"; // domyślny użtytkownik sql 
$pass = "";   // haslo puste 
$dbname = "UsersData"; 

$conn = new mysqli($host,$user,$pass,$dbname); 

if ($conn -> connect_error)
     {
         die("Błąd połacznie: " . $conn->connect_error); 
     }

     if($_SERVER["REQUEST_METHOD"]=="POST")
     {
         $email = $_POST["email"];
         $password = $_POST["password"];
     }


//skrypt LoginPage.php

session_start(); 

if(isset($_SESSION['log'])){

    header('location: shopPage.php');
    exit();

}elseif(isset($_POST["email"]) && isset($_POST['password'])) { 

    $sql = "SELECT * FROM `user` WHERE login = '$email';";
    $result = $conn -> query($sql); 

    if($result -> num_rows <= 0 )
    {
        echo"<script>alert('incorrectly entered data')</script>"; 
    }else{
         $row = $result->fetch_assoc();
         if($row["password"] == $_POST['password'])
         {
            $_SESSION['log'] = $email; 
            header('location: shopPage.php');
            exit();
         }else{
            echo"<script>alert('incorrectly entered data')</script>";   
         }
        }
    }
  $conn -> close(); 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ZooLogin</title>
    <link rel="stylesheet" href="logStyle.css">
</head>
<body>
<a href="Zoo-website.php"><button id="back">Back to Site</button></a>
    <div id="formPage">
    
        <h1> Log in </h1>
        <form action="https://localhost/zoo-Website/loginPage.php" method="POST">
            <p >Email: </p>
            <input class="logPut" type="email" name="email" value=""  size="25" required><br/>
            <p >Password: </p>
            <input class="logPut" type="password" name="password" value="" size="25" required><br/>
            <input id="submit" type="submit" value="Submit">
        </form>
      
       or  <a href="signinPage.php"><button id="signin">Sign On</button></a>

    </div>
    
</body>
</html>