<?php
session_start() ;
echo"<h2> Hello " . $_SESSION['log'] ."</h2> <hr>";  

header("refresh: 3, Zoo-website.php")
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HipoZoo</title>
    <link rel="stylesheet" href="shopStyle.css">
</head>
<body>
    <h1>Thank you for shopping!</h1>
</body>
</html>