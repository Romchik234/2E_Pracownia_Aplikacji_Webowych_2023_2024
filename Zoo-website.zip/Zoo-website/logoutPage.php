<?php

$host = "localhost";
$user = "root"; // domyślny użtytkownik sql 
$pass = "";   // haslo puste 
$dbname = "UsersData"; 

$conn = new mysqli($host,$user,$pass,$dbname); 

session_start(); 

if ($conn -> connect_error)
     {
         die("Błąd połacznie: " . $conn->connect_error); 
     }

     if(isset($_SESSION['log'])){
        unset($_SESSION['log']); 
        echo"<h1> Wylogowano!</h1>";
        header("Refresh: 1, url=Zoo-website.php");
        exit();
     }else
     {
        echo"<h1> Nie jestes zalogowany</h1>";
        header("Refresh: 1, url=Zoo-website.php");
        exit();
     }
    
     $conn -> close(); 

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hipo Out</title>
</head>
<body>
    
</body>
</html>