<?php
  session_start() ;
  echo"<h2> Hello " . $_SESSION['log'] ."</h2> <hr>";  
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="shopStyle.css">
    <title>HipoZoo</title>
    <script src="calculate.js"></script>
</head>
<body>
  <a href="Zoo-website.php"><button id= back> Back to main page</button></a>
  <div class="divShop">
  <h3>Tickets</h3>
    <form class="shop">
      
      <label for="adult">Adult: 120$</label>
      <input type="number" id="adult" name="adult" min="0" max="50"> <br>
      <label for="kids">Kids: 70$</label>
      <input type="number" id="kids" name="kids" min="0" max="50"><br>
      <label for="family">Family: 200$</label>
      <input type="number" id="family" name="family" min="0" max="50"><br>
      <label for="foradam">For Adam: 1200$</label>
      <input type="number" id="foradam" name="foradam" min="0" max="50"><br>
      <p id="sum">Sum: </p>
    <button type="button" onclick="calculate()" ondblclick ="confirm()">Pay</button>
    <p id="double"> </p>
    </form>
    </div>
</body>
</html>