<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HipoZoo</title>
    <link rel="stylesheet" href="styleMain.css">
</head>
<body>
    
    <header>
        <div id="divWithbuttons">
        <a href="Zoo-website.php"><button class = "buttons" type="reset">Start</button> </a><br>
            <a href="loginPage.php"><button class = "buttons">Log in</button> </a><br>
            <a href="loginPage.php"><button class = "buttons">Tickets</button></a> <br>
            <a href="logoutPage.php"><button class = "buttons">Log out </button></a><br>
        </div>

        <div id="logo"><h1><b>HipoZoo </b> </h1> <p><b> the best Zoo in all country for everyone!</b> </p></div>

        <div id="tickets">
            <p>Buy tickets NOW with 30% sale
                <a href="loginPage.php"><button type="submit" id="toShop">Buy tickets</button></a>
            </p>

        </div>
    </header>
    <div id="topBackground"></div>
    <main>
        <div id="picturesOfAnimals">
            <table id="gallery">
                <tr>
                    <td><img src="animals1.jpg" alt="animal" class="pctAnimals"></td>
                    <td><img src="animals2.jpg" alt="animal" class="pctAnimals"></td>
                    <td><img src="animals3.jpg" alt="animal" class="pctAnimals"></td>
                </tr>
                </tr>
                    <td><img src="animals4.jpg" alt="animal" class="pctAnimals"></td>
                    <td><img src="animals5.jpg" alt="animal" class="pctAnimals"></td>
                    <td><img src="animals6.jpg" alt="animal" class="pctAnimals"></td>
                </tr>
                
            </table>

        </div>
        <div class="mainItems"><p>Price and info - find all the details you need about our products/services here.</p></div>
        <div class="mainItems"><p>About us</p></div>
        <div class="mainItems"><p>123</p></div>

        <div id="mapAndInfo">
            <h2>Map and location: </h2>
            <div id="map">
                <img src="mapPicture.png" alt="mapPicture">
            </div>
            <div id="textAboutMap">
                <p>
                    Location Name: Eldoria Valley
                    Country: Veridonia
                    Region: Saphir Hills
                    Coordinates: 42.157° N, 87.930° E
                    Description: Nestled in the picturesque Saphir Hills, Eldoria Valley is a
                    tranquil, remote area known for its lush green meadows, crystal-clear rivers,
                    and towering pine forests. With an untouched beauty, this hidden gem offers a perfect
                    escape for nature lovers and adventure seekers alike.
                </p>
            </div>
            
        </div>
    </main>
    <br>
    <hr>
    <footer>
        <p>Roman Khazov 3E </p>
        <p>temat: ZOO</p>
    </footer>
</body>
</html>